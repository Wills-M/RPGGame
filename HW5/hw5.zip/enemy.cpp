#include "enemy.h"

//Since we don't actually want these to be used they don't need to be useful
//Abstract Classes are another way to do this, but they will come later
enemy::enemy(){}
